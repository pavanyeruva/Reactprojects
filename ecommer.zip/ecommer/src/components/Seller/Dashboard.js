import React, { useState, useEffect } from 'react'
import axios from "axios";
import { Link } from 'react-router-dom';
import Addproduct from '../Addproduct';
import ProductCrud from './ProductCrud';

function Dashboard() {
    const [products, setProducts] = useState([]);
    const [searchProduct, setSearchProduct] = useState('');
    useEffect(() => {
        axios.get(`http://localhost:3001/products`)
            .then(res => {
                console.log(res.data);
                setProducts(res.data);
            })
            .catch(err => console.log(err));
    }, []);
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-white py-3 shawdow-sm">
                <div className="container">
                    <a className="navbar-brand fw-bold fs-4" href="abc">
                        Shopping Mart
                    </a>
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
                            <div className="form-group has-search search">
                                &nbsp;&nbsp;&nbsp;
                                <input

                                    type="text"
                                    className="form-control"
                                    placeholder="Search"
                                    style={{ margin: "5px", padding: "6px", width: "50%" }}
                                    value={searchProduct}
                                    onChange={(e) => setSearchProduct(e.target.value)}
                                />

                            </div>
                            
                            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
                            <div className=" ">
                            <Addproduct /> 
                            </div>
                            

                            <div className="buttons">
                                
                                
                                <a className="nav-item active">
                                    <Link type="button" to="/" className="btn btn-danger ms-3">Log Out</Link>
                                </a>
                            </div>

                        </ul>

                    </div>
                </div>
            </nav><br />
            {

                products.filter(val => {
                    if (searchProduct === '') {
                        return val;
                    }
                    else if (val.productName.toLowerCase().includes(searchProduct.toLowerCase())) {
                        return val;
                    }
                }).map((product, key) => (<ProductCrud key={key} product={product} />))
            }


        </div>


    )
}

export default Dashboard
