import React, { Component } from 'react'
import {Link} from 'react-router-dom';
//import Contact from './Contact';
import Home from './Home';
import Reviews from './Reviews';

export class Header extends Component {
    render() {
        return (
            <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 shawdow-sm">
              <div class="container">
                <a class="navbar-brand fw-bold fs-4" href="abc">
                  Shopping Mart
                </a>
                <button
                  class="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                      <a class="nav-link active" aria-current="page" href='/'>
                        Home
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="abc">
                        Products
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="/Reviews">
                        Reviews
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="/Contact">
                        Contact
                      </a>
                    </li>
                  </ul>
                  <div className="buttons">
                  <Link to="/Admin" className="btn btn-outline-dark" >
                    <i className="fa fa-sign-in me-1"></i>Login
                  </Link>
                  <Link to="/FormValidation" className="btn btn-outline-dark ms-3" >
                    <i className="fa fa-user-plus me-1"></i>Register
                  </Link>
                    
                  </div>
                </div>
              </div>
            </nav>
            <Home />
            <Reviews />
            {/* <Contact /> */}

          </div>
          
      
        )
    }
}

export default Header