import React, { useState, useEffect } from 'react'
import axios from "axios";
import { Link } from 'react-router-dom';
import Crud from './Crud';
import { useLocation } from 'react-router-dom';


function Userdashboard(props) {
    const [products, setProducts] = useState([]);
    const [searchProduct, setSearchProduct] = useState('');
    const Location = useLocation();
    const [user, setUser] = useState([]);
    let emailId = Location.state;


    useEffect(() => {
        console.log(emailId)
        axios.get(`http://localhost:3001/products`)
            .then(res => {
                console.log(res.data);
                setProducts(res.data);
            })
            .catch(err => console.log(err));
        axios.get(`http://localhost:3001/Registration?emailId=${emailId}`)
            .then(res => {
                console.log(res)
                setUser(res.data)
            })
            .catch(error => { console.log(error) })
    }, []);
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-white py-3 shawdow-sm">
                <div className="container">
                    <a className="navbar-brand fw-bold fs-4" href="abc">
                        Shopping Mart
                    </a>
                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent"
                        aria-expanded="false"
                        aria-label="Toggle navigation"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
                            <div className="form-group has-search search">
                                &nbsp;&nbsp;&nbsp;
                                <input

                                    type="text"
                                    className="form-control"
                                    placeholder="Search"
                                    style={{ margin: "5px", padding: "6px", width: "50%" }}
                                    value={searchProduct}
                                    onChange={(e) => setSearchProduct(e.target.value)}
                                />

                            </div>

                            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;
                            <div className=" ">

                            </div>


                            <div className="buttons">

                                <Link
                                    to={{
                                        pathname: `/Cart`,
                                        state: { emailId: emailId }
                                    }}

                                    className="btn btn-outline-dark ms-3" >
                                    <i className="fa fa-shopping-cart me-1"></i>Cart
                                </Link>
                                <a className="nav-item active">
                                    <Link type="button" to="/" className="btn btn-danger ms-3">Log Out</Link>
                                </a>
                            </div>

                        </ul>

                    </div>
                </div>
            </nav><br />
            <div class="col-md-12">
                <h1>
                    Products <b>List</b>
                </h1>
            </div>
            <br />
            {

                products.filter(val => {
                    if (searchProduct === '') {
                        return val;
                    }
                    else if (val.productName.toLowerCase().includes(searchProduct.toLowerCase())) {
                        return val;
                    }
                }).map((product, key) => (<Crud emailId={emailId} key={key} product={product} />))
            }


        </div>


    )
}

export default Userdashboard
