import axios from "axios";
import { useNavigate } from "react-router-dom";
import React from 'react';
import { Link } from "react-router-dom";
import { useState } from 'react';

//import { Link } from "react-router-dom";
function Crud(props) {
  const navigate = useNavigate();
  const [currentProduct, setCurrentProduct] = useState([])
  const [borrow, setBorrow] = useState([])


  const handleClick = (event) => {
    let productName = event.target.value
    axios.get(`http://localhost:3001/products?productName=${productName}`)
      .then(res => {
        console.log(res)
        setCurrentProduct(res.data)
      })
      .catch(error => { console.log(error) })
    console.log(currentProduct)
  }
  const handleBorrowClick = (event) => {
    axios.post('http://localhost:3001/cart', {
      productName: currentProduct.map(product => (product.productName))[0],
      productId: currentProduct.map(product => (product.id))[0],
      productPrice: currentProduct.map(product => (product.productPrice))[0],
      emailId: props.emailId,
      cart: true

    })

      .then(res => { console.log(res) })
      .catch(error => { console.log(error) })
  }

  return (
    <div class="container-2 py-5">

      <div class="row">
        <div class="col-lg-8 mx-auto">

          <ul class="list-group shadow">

            <li class="list-group-item">

              <div class="media align-items-lg-center flex-column flex-lg-row p-3">
                <div class="media-body order-2 order-lg-1">
                  <img className="addPic ml-lg-5 order-1 order-lg-2" src={props.product.pic} alt="pic" width="200" />
                  <button
                    className="btn btn-success ms-5 "
                    value={props.product.productName}
                    onClick={handleClick}
                  >
                    Add Product
                  </button>

                  <button
                    className="btn btn-danger  ms-2 "
                    onClick={handleBorrowClick}

                  >
                    Add to Cart
                  </button>
                  <h5 class="mt-0 font-weight-bold mb-2">{props.product.productName}</h5>
                  <p class="font-italic text-muted mb-0 small">Description: {props.product.description}</p>
                  <div class="d-flex align-items-center justify-content-between mt-1">
                    <h6 class="font-weight-bold my-2">{props.product.productPrice}</h6>
                    {/* <button onClick={() => addCart(props.product.pid)}>Add to Cart</button> */}
                    <ul class="list-inline small">
                      <li class="list-inline-item m-0"><i class="fa fa-star text-success"></i></li>
                      <li class="list-inline-item m-0"><i class="fa fa-star text-success"></i></li>
                      <li class="list-inline-item m-0"><i class="fa fa-star text-success"></i></li>
                      <li class="list-inline-item m-0"><i class="fa fa-star text-success"></i></li>
                      <li class="list-inline-item m-0"><i class="fa fa-star-o text-gray"></i></li>
                    </ul>

                  </div>
                  <div>

                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default Crud

